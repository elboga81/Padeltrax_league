import 'package:flutter/material.dart';
import 'bookings_page.dart';
import 'table_tabs.dart';
import 'schedule_page.dart';
import 'player.dart';

class MainDashboard extends StatefulWidget {
  const MainDashboard({Key? key}) : super(key: key);

  @override
  _MainDashboardState createState() => _MainDashboardState();
}

class _MainDashboardState extends State<MainDashboard> {
  int _selectedIndex = 0;

  static List<Player> players = [
    Player(name: 'Player 1', rating: 5.0, profileImage: 'assets/profile.png'),
    Player(name: 'Player 2', rating: 6.0, profileImage: 'assets/profile.png'),
    // Add more players here
  ];

  static List<Widget> widgetOptions = <Widget>[
    BookingsPage(players: players),
    TableTabs(),
    SchedulePage(players: players),
  ];

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Padeltrax Dashboard'),
        backgroundColor: Colors.blue,
      ),
      body: Center(
        child: widgetOptions.elementAt(_selectedIndex),
      ),
      bottomNavigationBar: BottomNavigationBar(
        items: const [
          BottomNavigationBarItem(
            icon: Icon(Icons.calendar_today),
            label: 'Bookings',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.table_chart),
            label: 'Table',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.schedule),
            label: 'Schedule',
          ),
        ],
        currentIndex: _selectedIndex,
        selectedItemColor: Colors.blue,
        onTap: _onItemTapped,
      ),
    );
  }
}
