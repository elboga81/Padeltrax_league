class Player {
  final String name;
  final double rating;
  final String profileImage;
  String signedDay;
  String signedTimeslot;

  Player({
    required this.name,
    required this.rating,
    required this.profileImage,
    this.signedDay = '',
    this.signedTimeslot = '',
  });
}
