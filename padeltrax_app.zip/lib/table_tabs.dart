import 'package:flutter/material.dart';
import 'form_view.dart';
import 'match_results_view.dart';

class TableTabs extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2, // Number of tabs
      child: Scaffold(
        appBar: AppBar(
          title: Text('Table'),
          backgroundColor: Colors.blue,
          bottom: TabBar(
            tabs: [
              Tab(text: 'Form'),
              Tab(text: 'Match Results'),
            ],
          ),
        ),
        body: TabBarView(
          children: [
            FormView(), // Display the Form view here
            MatchResultsView(), // Display the Match Results view here
          ],
        ),
      ),
    );
  }
}
