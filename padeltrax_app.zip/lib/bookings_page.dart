import 'package:flutter/material.dart';
import 'player.dart';
import 'booking_details_page.dart'; // Import the Booking Details Page

class BookingsPage extends StatelessWidget {
  final List<Player> players;

  const BookingsPage({Key? key, required this.players}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Bookings'),
        backgroundColor: Colors.blue,
      ),
      body: ListView.builder(
        itemCount: players.length,
        itemBuilder: (context, index) {
          final player = players[index];
          return ListTile(
            leading: CircleAvatar(
              backgroundImage: AssetImage(player.profileImage),
            ),
            title: Text(player.name),
            subtitle: Text('Current Form: ${player.rating}'),
            onTap: () {
              // Navigate to the Booking Details Page
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => BookingDetailsPage(player: player),
                ),
              );
            },
          );
        },
      ),
    );
  }
}
