import 'package:flutter/material.dart';

class MatchResultsView extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Match Results'),
        backgroundColor: Colors.blue,
      ),
      body: ListView(
        padding: EdgeInsets.all(16.0),
        children: [
          DataTable(
            columns: [
              DataColumn(label: Text('Rank')),
              DataColumn(label: Text('Player')),
              DataColumn(label: Text('Played')),
              DataColumn(label: Text('W')),
              DataColumn(label: Text('D')),
              DataColumn(label: Text('L')),
              DataColumn(label: Text('Win %')),
              DataColumn(label: Text('Sets Won')),
              DataColumn(label: Text('Sets Lost')),
            ],
            rows: List<DataRow>.generate(
              20, // Replace this with the actual number of players
              (index) => DataRow(
                cells: [
                  DataCell(Text('${index + 1}')), // Rank
                  DataCell(Text('Player ${index + 1}')), // Player name
                  DataCell(Text('10')), // Matches played
                  DataCell(Text('6')), // Wins
                  DataCell(Text('2')), // Draws
                  DataCell(Text('2')), // Losses
                  DataCell(Text('60%')), // Win percentage
                  DataCell(Text('18')), // Sets won
                  DataCell(Text('10')), // Sets lost
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
