import 'package:flutter/material.dart';

class FormView extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Form View'),
        backgroundColor: Colors.blue,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Player Rankings',
              style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 20),
            Expanded(
              child: ListView.builder(
                itemCount: 10, // Change this to your total player count
                itemBuilder: (context, index) {
                  return ListTile(
                    leading: CircleAvatar(
                      backgroundColor: Colors.blue,
                      child: Text('${index + 1}'), // Player ranking position
                    ),
                    title: Text('Player ${index + 1}'),
                    subtitle: Text('Points: ${(index + 1) * 10}.0'),
                    trailing: Wrap(
                      spacing: 6,
                      children: List.generate(
                        6, // Last 6 matches results
                        (matchIndex) => Icon(
                          Icons.circle, // Icon to represent win/loss
                          color:
                              (matchIndex % 2 == 0) ? Colors.green : Colors.red,
                          size: 10,
                        ),
                      ),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
