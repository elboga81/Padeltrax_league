import 'package:flutter/material.dart';
import 'player.dart';

class SchedulePage extends StatelessWidget {
  final List<Player> players;

  SchedulePage({required this.players});

  // Filter players based on the selected day and timeslot
  List<Player> getPlayersForDayAndTimeslot(String day, String timeslot) {
    return players
        .where((player) =>
            player.signedDay == day && player.signedTimeslot == timeslot)
        .toList();
  }

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 5, // Number of weekdays
      child: Scaffold(
        appBar: AppBar(
          title: Text('Schedule'),
          bottom: TabBar(
            tabs: [
              Tab(text: 'Monday'),
              Tab(text: 'Tuesday'),
              Tab(text: 'Wednesday'),
              Tab(text: 'Thursday'),
              Tab(text: 'Friday'),
            ],
          ),
        ),
        body: TabBarView(
          children: [
            buildDaySchedule('Monday'),
            buildDaySchedule('Tuesday'),
            buildDaySchedule('Wednesday'),
            buildDaySchedule('Thursday'),
            buildDaySchedule('Friday'),
          ],
        ),
      ),
    );
  }

  // Widget to display the schedule for each day
  Widget buildDaySchedule(String day) {
    return Column(
      children: [
        Text(
          'Early Session',
          style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
        ),
        Expanded(
          child: ListView.builder(
            itemCount:
                getPlayersForDayAndTimeslot(day, 'Early Timeslot').length,
            itemBuilder: (context, index) {
              var player =
                  getPlayersForDayAndTimeslot(day, 'Early Timeslot')[index];
              return ListTile(
                leading: CircleAvatar(
                  backgroundImage: AssetImage(player.profileImage),
                ),
                title: Text(player.name),
                subtitle: Text('Current Form: ${player.rating}'),
              );
            },
          ),
        ),
        Text(
          'Later Session',
          style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
        ),
        Expanded(
          child: ListView.builder(
            itemCount:
                getPlayersForDayAndTimeslot(day, 'Later Timeslot').length,
            itemBuilder: (context, index) {
              var player =
                  getPlayersForDayAndTimeslot(day, 'Later Timeslot')[index];
              return ListTile(
                leading: CircleAvatar(
                  backgroundImage: AssetImage(player.profileImage),
                ),
                title: Text(player.name),
                subtitle: Text('Current Form: ${player.rating}'),
              );
            },
          ),
        ),
      ],
    );
  }
}
