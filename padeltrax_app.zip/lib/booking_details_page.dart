import 'package:flutter/material.dart';
import 'player.dart';

class BookingDetailsPage extends StatefulWidget {
  final Player player;

  const BookingDetailsPage({Key? key, required this.player}) : super(key: key);

  @override
  _BookingDetailsPageState createState() => _BookingDetailsPageState();
}

class _BookingDetailsPageState extends State<BookingDetailsPage> {
  final Map<String, String> selectedTimeslots = {};

  void _selectTimeslot(String day, String timeslot) {
    setState(() {
      selectedTimeslots[day] = timeslot;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Bookings for ${widget.player.name}'),
        backgroundColor: Colors.blue,
      ),
      body: Column(
        children: [
          SizedBox(height: 20),
          CircleAvatar(
            backgroundImage: AssetImage(widget.player.profileImage),
            radius: 50,
          ),
          SizedBox(height: 20),
          Text('Player: ${widget.player.name}'),
          Text('Rating: ${widget.player.rating}'),
          SizedBox(height: 20),
          ...buildDayTimeslotButtons(),
          SizedBox(height: 20),
          ElevatedButton(
            onPressed: _saveSelection,
            child: const Text('Save'),
          ),
          ElevatedButton(
            onPressed: _cancelSelection,
            child: const Text('Cancel'),
          ),
        ],
      ),
    );
  }

  List<Widget> buildDayTimeslotButtons() {
    const days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'];
    const timeslots = ['Early Timeslot', 'Later Timeslot', 'Play Either'];

    return days.map((day) {
      return Column(
        children: [
          Text(day),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: timeslots.map((timeslot) {
              return ElevatedButton(
                onPressed: () => _selectTimeslot(day, timeslot),
                style: ElevatedButton.styleFrom(
                  backgroundColor: selectedTimeslots[day] == timeslot
                      ? Colors.blue
                      : Colors.grey,
                ),
                child: Text(timeslot),
              );
            }).toList(),
          ),
        ],
      );
    }).toList();
  }

  void _saveSelection() {
    // Implement save functionality
  }

  void _cancelSelection() {
    setState(() {
      selectedTimeslots.clear();
    });
  }
}
